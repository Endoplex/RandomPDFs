To run the program, compile using "g++ -o main main.cpp

The program does not work as intended. Too many issues with memory allocation and concatenation.

run using command ./main 100 10 10 small.txt output.txt

File prints out to a file named after the last argument