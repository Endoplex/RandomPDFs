#include <iostream> 
#include <fstream>
#include <string>
#include <vector>
using namespace std;

char** populateMatrix(string file){
    ifstream input; input.open(file, ios::in);
    
    string tp; int count = 0;

    if(input.is_open()){
        while(getline(input, tp)){
            count++;
            
        }
        input.close();
    }
    
    char** matrix = (char**) calloc(count, sizeof(char*));
    for(int x = 0; x < count; x++) matrix[x] = (char*) calloc(2, sizeof(char));

    input.open(file, ios::in);
    count = 0;
    if(input.is_open()){
        while(getline(input, tp)){
            matrix[count][0] = tp[0];
            matrix[count][1] = tp[2];
            count++;
        }
        input.close();
    }
    return matrix;
}

int getLength(string file){
    ifstream input; input.open(file, ios::in);
    
    string tp; int count = 0;

     if(input.is_open()){
        while(getline(input, tp)){
            count++;
            
        }
        input.close();
    }
    return count;
}
int* createArray(int size){
    int* result = new int[size];
    for(int x = 0; x < size; x++) result[x] = 0;
    return result;
}

int main(int argc, char** argv){


    int memsize, swapin, swapout, count = 0, timeElapsed = 0;
    ofstream outFile;
     //0=R/W, 1=PageNum, 2=F/H, 3=PageNum, 4=TimeUsed, 5=Total
    //F=Fault H=Hit PageNum = -1 *No page is Removed*
    memsize = atoi(argv[1]);
    cout << memsize << "\n";
    swapin = atoi(argv[2]);
    cout << swapin << "\n";
    swapout = atoi(argv[3]);
    cout << swapout << "\n";
    char** input = populateMatrix(argv[4]);
    outFile.open(argv[5], ios::out | ofstream::app);
    outFile.clear();
    int* MEM = createArray(memsize);

    // for(int i = 0; i < 22; i++){
    //     for(int j = 0; j < 2; j++){
    //         cout << input[i][j] << " ";
    //     }
    //     cout << i << "\n";
    // }
    for(int i = 0; i < getLength(argv[4]); i++) {
        string result[6];
        int temp = timeElapsed, place = 0;
        if(input[i][0] == 'R') result[0] = 'R';
        else result[0] = 'W';

        result[1] = input[i][1]; 
        result[2] = 'F';
        result[3] = MEM[count];
        result[4] = '0';
        result[5] = to_string(timeElapsed);

        for(int j = 0; j < count; j++){
            result[3] = result[j][3];
            if((input[i][1]) - '0' == MEM[j]) {
                result[2] = 'H';
                result[3] = "-1";
                break;
            }
            place++;
        }
        MEM[count] = input[i][1];
        if(result[2] == "F"){
            if(place != count){
                MEM[count] = input[i][1];
                timeElapsed += swapout;
                result[4] = to_string(swapout);
                result[5] = to_string(timeElapsed);
            }
            else{
                MEM[count] = input[i][1];
                timeElapsed += swapin;
                result[4] = to_string(swapin);
                result[5] = to_string(timeElapsed);
            }
        }

        count ++; 
        if(count >= sizeof(MEM)) count = 0;
        outFile << (i + 1) << ". ";
        for(int l = 0; l < 6; l++) outFile << result[l] << " ";
        outFile << "\n";
        
    }
    outFile.close();

}